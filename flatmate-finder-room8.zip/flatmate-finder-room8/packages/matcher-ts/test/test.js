/* eslint-disable @typescript-eslint/no-var-requires */
// Node-based tests for the matcher TS library. These tests avoid
// external dependencies like vitest and run after the library has been
// compiled to plain JavaScript. To execute run:
//   npm run build --workspace=packages/matcher-ts && node packages/matcher-ts/test/test.js
const assert = require('assert');
const { computeScore, getTopKMatches } = require('../dist/index.js');

function makeProfile(overrides = {}) {
  const base = {
    uid: 'x',
    city: 'Madrid',
    budgetMin: 400,
    budgetMax: 600,
    moveInStart: new Date('2025-09-01'),
    moveInEnd: new Date('2025-09-30'),
    cleanliness: 3,
    noise: 3,
    social: 3,
    visitors: 3,
    smoking: false,
    bedtime: 23,
    wake: 7,
    zones: new Set(['Centro']),
    gender: 'female',
    language: 'es',
  };
  return { ...base, ...overrides };
}

// Test perfect match
{
  const a = makeProfile({ cleanliness: 5, noise: 1, social: 5, visitors: 1, smoking: true, bedtime: 22, wake: 8, zones: new Set(['Centro', 'Sol']) });
  const b = makeProfile({ uid: 'b', cleanliness: 5, noise: 1, social: 5, visitors: 1, smoking: true, bedtime: 22, wake: 8, zones: new Set(['Centro', 'Sol']) });
  const [score] = computeScore(a, b);
  assert(Math.abs(score - 100) < 0.01, 'identical profiles should score ~100');
}
// Test hard constraint failure due to budget
{
  const a = makeProfile();
  const b = makeProfile({ uid: 'b', budgetMin: 1000, budgetMax: 1200 });
  const [score] = computeScore(a, b);
  assert(score === 0, 'budget mismatch should give score 0');
}
// Test ordering by similarity: candidate with identical scores should rank highest
{
  const user = makeProfile({ uid: 'user' });
  const best = makeProfile({ uid: 'best', cleanliness: 3, noise: 3, social: 3 });
  const high = makeProfile({ uid: 'high', cleanliness: 5, noise: 5, social: 5 });
  const low = makeProfile({ uid: 'low', cleanliness: 1, noise: 1, social: 1 });
  const res = getTopKMatches(user, [high, best, low], 2);
  assert(res.length === 2, 'should return 2 matches');
  assert(res[0][0].uid === 'best', 'candidate with identical preferences should rank first');
  assert(res[1][0].uid === 'high', 'high candidate should rank second');
}
console.log('All matcher-ts tests passed');