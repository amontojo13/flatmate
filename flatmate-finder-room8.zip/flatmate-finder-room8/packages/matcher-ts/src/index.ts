/**
 * Pure TypeScript implementation of the room8 matching algorithm.
 *
 * This module mirrors the Python reference implementation in algorithms/python/matcher.py.
 * It exports functions to compute a compatibility score between two profiles and to
 * retrieve the top-K matches from a list of candidates. The implementation is
 * intentionally free of any Firebase or React dependencies so that it can be used
 * both on the client (in the web app) and on the server (in Cloud Functions).
 */

export interface Profile {
  uid: string;
  city: string;
  budgetMin: number;
  budgetMax: number;
  moveInStart: Date;
  moveInEnd: Date;
  cleanliness: number;
  noise: number;
  social: number;
  visitors: number;
  smoking: boolean;
  bedtime: number;
  wake: number;
  zones: Set<string>;
  gender: string;
  language: string;
  genderRequired?: boolean;
  languageRequired?: boolean;
  requiredPartnerGender?: string;
  requiredPartnerLanguage?: string;
}

/** Hard constraint check between two profiles. */
export function hardConstraintsOk(a: Profile, b: Profile): boolean {
  // City
  if (a.city.toLowerCase() !== b.city.toLowerCase()) return false;
  // Budget overlap
  if (a.budgetMax < b.budgetMin || b.budgetMax < a.budgetMin) return false;
  // Move-in window ±45 days
  const tolerance = 45 * 24 * 60 * 60 * 1000; // 45 days in ms
  const aStart = new Date(a.moveInStart.getTime() - tolerance);
  const aEnd = new Date(a.moveInEnd.getTime() + tolerance);
  const bStart = new Date(b.moveInStart.getTime() - tolerance);
  const bEnd = new Date(b.moveInEnd.getTime() + tolerance);
  if (aEnd < bStart || bEnd < aStart) return false;
  // Gender requirement
  if (a.genderRequired) {
    const required = a.requiredPartnerGender || a.gender;
    if (b.gender.toLowerCase() !== required.toLowerCase()) return false;
  }
  if (b.genderRequired) {
    const required = b.requiredPartnerGender || b.gender;
    if (a.gender.toLowerCase() !== required.toLowerCase()) return false;
  }
  // Language requirement
  if (a.languageRequired) {
    const required = a.requiredPartnerLanguage || a.language;
    if (b.language.toLowerCase() !== required.toLowerCase()) return false;
  }
  if (b.languageRequired) {
    const required = b.requiredPartnerLanguage || b.language;
    if (a.language.toLowerCase() !== required.toLowerCase()) return false;
  }
  return true;
}

// Similarity helpers
function likertSimilarity(a: number, b: number): number {
  const diff = Math.abs(a - b);
  return Math.max(0, 1 - diff / 4);
}

function binarySimilarity(a: boolean, b: boolean): number {
  return a === b ? 1 : 0.3;
}

function circularSimilarity(a: number, b: number): number {
  let dist = Math.abs(a - b);
  if (dist > 12) dist = 24 - dist;
  return Math.max(0, 1 - dist / 12);
}

function intervalOverlapRatio(min1: number, max1: number, min2: number, max2: number): number {
  const intersect = Math.max(0, Math.min(max1, max2) - Math.max(min1, min2));
  const union = Math.max(max1, max2) - Math.min(min1, min2);
  if (union === 0) return 0;
  return intersect > 0 ? intersect / union : 0;
}

function jaccardSimilarity(set1: Set<string>, set2: Set<string>): number {
  if (set1.size === 0 && set2.size === 0) return 1;
  if (set1.size === 0 || set2.size === 0) return 0;
  const intersection = new Set([...set1].filter((x) => set2.has(x))).size;
  const union = new Set([...set1, ...set2]).size;
  return union > 0 ? intersection / union : 0;
}

export interface ScoreBreakdown {
  [key: string]: number;
}

/**
 * Compute the overall compatibility score between two profiles.
 *
 * Returns a score in the range [0, 100] and a per-feature breakdown
 * (contributions summing to the total). If hard constraints fail, 0 and
 * an empty breakdown are returned.
 */
export function computeScore(a: Profile, b: Profile): [number, ScoreBreakdown] {
  if (!hardConstraintsOk(a, b)) return [0, {}];
  const similarities: { [key: string]: number } = {
    cleanliness: likertSimilarity(a.cleanliness, b.cleanliness),
    noise: likertSimilarity(a.noise, b.noise),
    social: likertSimilarity(a.social, b.social),
    visitors: likertSimilarity(a.visitors, b.visitors),
    smoking: binarySimilarity(a.smoking, b.smoking),
    bedtime: circularSimilarity(a.bedtime, b.bedtime),
    wake: circularSimilarity(a.wake, b.wake),
    budget: intervalOverlapRatio(a.budgetMin, a.budgetMax, b.budgetMin, b.budgetMax),
    location: jaccardSimilarity(a.zones, b.zones),
  };
  const weights: { [key: string]: number } = {
    cleanliness: 0.18,
    noise: 0.14,
    social: 0.14,
    visitors: 0.10,
    smoking: 0.12,
    bedtime: 0.08,
    wake: 0.06,
    budget: 0.10,
    location: 0.08,
  };
  let total = 0;
  const contributions: ScoreBreakdown = {};
  for (const key of Object.keys(weights)) {
    const contrib = similarities[key] * weights[key] * 100;
    contributions[key] = contrib;
    total += contrib;
  }
  return [total, contributions];
}

/**
 * Compute the top-K matches for a user from a list of candidates.
 */
export function getTopKMatches(
  user: Profile,
  candidates: Iterable<Profile>,
  k: number = 20,
): Array<[Profile, number, ScoreBreakdown]> {
  const scored: Array<[Profile, number, ScoreBreakdown]> = [];
  for (const other of candidates) {
    if (other.uid === user.uid) continue;
    const [score, breakdown] = computeScore(user, other);
    if (score > 0) scored.push([other, score, breakdown]);
  }
  scored.sort((a, b) => b[1] - a[1]);
  return scored.slice(0, k);
}