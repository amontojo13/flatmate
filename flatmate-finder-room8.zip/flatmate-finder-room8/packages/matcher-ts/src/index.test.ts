import { describe, it, expect } from 'vitest';
import { computeScore, getTopKMatches, hardConstraintsOk, Profile } from './index';

// Helper to build a profile with defaults
function makeProfile(overrides: Partial<Profile> = {}): Profile {
  const base: Profile = {
    uid: 'x',
    city: 'Madrid',
    budgetMin: 400,
    budgetMax: 600,
    moveInStart: new Date('2025-09-01'),
    moveInEnd: new Date('2025-09-30'),
    cleanliness: 3,
    noise: 3,
    social: 3,
    visitors: 3,
    smoking: false,
    bedtime: 23,
    wake: 7,
    zones: new Set(['Centro']),
    gender: 'female',
    language: 'es',
  };
  return { ...base, ...overrides };
}

describe('hardConstraintsOk', () => {
  it('fails when cities differ', () => {
    const a = makeProfile({ city: 'Madrid' });
    const b = makeProfile({ city: 'Barcelona' });
    expect(hardConstraintsOk(a, b)).toBe(false);
  });
  it('fails when budgets do not overlap', () => {
    const a = makeProfile({ budgetMin: 400, budgetMax: 600 });
    const b = makeProfile({ budgetMin: 700, budgetMax: 800 });
    expect(hardConstraintsOk(a, b)).toBe(false);
    const c = makeProfile({ uid: 'c', budgetMin: 600, budgetMax: 700 });
    expect(hardConstraintsOk(a, c)).toBe(true);
  });
});

describe('computeScore', () => {
  it('returns 100 for identical profiles', () => {
    const a = makeProfile({
      cleanliness: 5,
      noise: 1,
      social: 5,
      visitors: 1,
      smoking: true,
      bedtime: 22,
      wake: 8,
      zones: new Set(['Centro', 'Sol']),
    });
    const b = makeProfile({
      uid: 'b',
      cleanliness: 5,
      noise: 1,
      social: 5,
      visitors: 1,
      smoking: true,
      bedtime: 22,
      wake: 8,
      zones: new Set(['Centro', 'Sol']),
    });
    const [score] = computeScore(a, b);
    expect(score).toBeCloseTo(100, 2);
  });
  it('returns 0 when hard constraints fail', () => {
    const a = makeProfile({});
    const b = makeProfile({ uid: 'b', budgetMin: 1000, budgetMax: 1200 });
    const [score] = computeScore(a, b);
    expect(score).toBe(0);
  });
});

describe('getTopKMatches', () => {
  it('orders matches by descending score', () => {
    const user = makeProfile({ uid: 'user' });
    const candidates: Profile[] = [
      makeProfile({ uid: 'good', cleanliness: 5, noise: 5, social: 5 }),
      makeProfile({ uid: 'ok', cleanliness: 3, noise: 3, social: 3 }),
      makeProfile({ uid: 'bad', cleanliness: 1, noise: 1, social: 1 }),
    ];
    const result = getTopKMatches(user, candidates, 2);
    expect(result.length).toBe(2);
    expect(result[0][0].uid).toBe('good');
    expect(result[1][0].uid).toBe('ok');
  });
});