import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/ProfilePage';
import QuizPage from './pages/QuizPage';
import MatchesPage from './pages/MatchesPage';
import ChatPage from './pages/ChatPage';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth } from './firebase';

/**
 * The top-level application component sets up routing and protects routes
 * behind authentication. When the user is not signed in they are
 * redirected to the login page. When signed in they can access profile,
 * quiz, matches and chat pages.
 */
const App: React.FC = () => {
  const [user, loading] = useAuthState(auth);
  if (loading) return <p>Loading…</p>;
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/profile" /> : <LoginPage />} />
      <Route path="/profile" element={user ? <ProfilePage /> : <Navigate to="/login" />} />
      <Route path="/quiz" element={user ? <QuizPage /> : <Navigate to="/login" />} />
      <Route path="/matches" element={user ? <MatchesPage /> : <Navigate to="/login" />} />
      <Route path="/chat/:peerUid" element={user ? <ChatPage /> : <Navigate to="/login" />} />
      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  );
};

export default App;