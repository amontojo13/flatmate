import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';

/**
 * QuizPage collects the user's lifestyle preferences. The form normalizes
 * inputs to the ranges expected by the matching algorithm and saves
 * them to Firestore under profiles/{uid}. After submission the user is
 * redirected to the matches page.
 */
const QuizPage: React.FC = () => {
  const [user] = useAuthState(auth);
  const navigate = useNavigate();
  // Likert scales 1–5
  const [cleanliness, setCleanliness] = useState(3);
  const [noise, setNoise] = useState(3);
  const [social, setSocial] = useState(3);
  const [visitors, setVisitors] = useState(3);
  const [smoking, setSmoking] = useState(false);
  const [budgetMin, setBudgetMin] = useState(400);
  const [budgetMax, setBudgetMax] = useState(600);
  const [bedtime, setBedtime] = useState(23);
  const [wake, setWake] = useState(7);
  const [zones, setZones] = useState('Centro');
  const [gender, setGender] = useState('female');
  const [language, setLanguage] = useState('es');
  const [genderRequired, setGenderRequired] = useState(false);
  const [languageRequired, setLanguageRequired] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  if (!user) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);
    const profileRef = doc(db, 'profiles', user.uid);
    const profileData = {
      city: 'Madrid', // Hard-coded for demo; in practice ask user
      budgetMin,
      budgetMax,
      moveInStart: new Date().toISOString(), // default now; should collect from user
      moveInEnd: new Date(new Date().setMonth(new Date().getMonth() + 1)).toISOString(),
      cleanliness,
      noise,
      social,
      visitors,
      smoking,
      bedtime,
      wake,
      zones: zones.split(',').map((z) => z.trim()),
      gender,
      language,
      genderRequired,
      languageRequired,
    };
    try {
      await setDoc(profileRef, profileData);
      setMessage('Saved! Redirecting…');
      setTimeout(() => navigate('/matches'), 1000);
    } catch (err: any) {
      setMessage(err.message);
    }
  }

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Lifestyle Quiz</h1>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <label>
          Cleanliness: {cleanliness}
          <input type="range" min={1} max={5} value={cleanliness} onChange={(e) => setCleanliness(Number(e.target.value))} />
        </label>
        <label>
          Noise tolerance: {noise}
          <input type="range" min={1} max={5} value={noise} onChange={(e) => setNoise(Number(e.target.value))} />
        </label>
        <label>
          Sociability: {social}
          <input type="range" min={1} max={5} value={social} onChange={(e) => setSocial(Number(e.target.value))} />
        </label>
        <label>
          Visitors frequency: {visitors}
          <input type="range" min={1} max={5} value={visitors} onChange={(e) => setVisitors(Number(e.target.value))} />
        </label>
        <label>
          Do you smoke?
          <input type="checkbox" checked={smoking} onChange={(e) => setSmoking(e.target.checked)} />
        </label>
        <label>
          Budget min (€)
          <input type="number" value={budgetMin} onChange={(e) => setBudgetMin(Number(e.target.value))} />
        </label>
        <label>
          Budget max (€)
          <input type="number" value={budgetMax} onChange={(e) => setBudgetMax(Number(e.target.value))} />
        </label>
        <label>
          Bedtime (0–23)
          <input type="number" min={0} max={23} value={bedtime} onChange={(e) => setBedtime(Number(e.target.value))} />
        </label>
        <label>
          Wake time (0–23)
          <input type="number" min={0} max={23} value={wake} onChange={(e) => setWake(Number(e.target.value))} />
        </label>
        <label>
          Preferred zones (comma separated)
          <input type="text" value={zones} onChange={(e) => setZones(e.target.value)} />
        </label>
        <label>
          Your gender
          <select value={gender} onChange={(e) => setGender(e.target.value)}>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="other">Other</option>
          </select>
        </label>
        <label>
          Primary language
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            <option value="es">Spanish</option>
            <option value="en">English</option>
            <option value="fr">French</option>
          </select>
        </label>
        <label>
          Require same gender?
          <input type="checkbox" checked={genderRequired} onChange={(e) => setGenderRequired(e.target.checked)} />
        </label>
        <label>
          Require same language?
          <input type="checkbox" checked={languageRequired} onChange={(e) => setLanguageRequired(e.target.checked)} />
        </label>
        <button type="submit">Save & find matches</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default QuizPage;