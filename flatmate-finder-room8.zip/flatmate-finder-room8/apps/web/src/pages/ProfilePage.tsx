import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';

/**
 * ProfilePage fetches and displays the user's profile. For the MVP this
 * page simply shows the current user's email and provides navigation to
 * the lifestyle quiz. You could extend it to allow editing of basic
 * information and preferences.
 */
const ProfilePage: React.FC = () => {
  const [user] = useAuthState(auth);
  const [profileExists, setProfileExists] = useState<boolean | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    // Check if the user's quiz/profile exists
    getDoc(doc(db, 'profiles', user.uid))
      .then((snapshot) => {
        setProfileExists(snapshot.exists());
      })
      .catch(() => {
        setProfileExists(false);
      });
  }, [user]);

  if (!user) return null;
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome, {user.email}</h1>
      <p>{profileExists === null ? 'Loading profile…' : profileExists ? 'Profile found' : 'No profile yet'}</p>
      <button onClick={() => navigate('/quiz')}>Fill or edit lifestyle quiz</button>
      <button onClick={() => navigate('/matches')} style={{ marginLeft: '1rem' }}>
        Find matches
      </button>
      <button onClick={() => auth.signOut()} style={{ marginLeft: '1rem' }}>
        Sign out
      </button>
    </div>
  );
};

export default ProfilePage;