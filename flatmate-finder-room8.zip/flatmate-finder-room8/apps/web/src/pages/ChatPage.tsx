import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '../firebase';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
} from 'firebase/firestore';

interface Message {
  id: string;
  text: string;
  sender: string;
  createdAt: any;
}

/**
 * ChatPage displays a simple 1:1 chat between the current user and a peer
 * selected from the matches list. Messages are stored in Firestore under
 * conversations/{conversationId}/messages. The conversation ID is
 * deterministic: the concatenation of the two UIDs sorted alphabetically.
 */
const ChatPage: React.FC = () => {
  const { peerUid } = useParams();
  const [user] = useAuthState(auth);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    if (!user || !peerUid) return;
    const ids = [user.uid, peerUid].sort();
    const convId = ids.join('_');
    const messagesRef = collection(db, 'conversations', convId, 'messages');
    const q = query(messagesRef, orderBy('createdAt'));
    const unsub = onSnapshot(q, (snapshot) => {
      const msgs: Message[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        msgs.push({ id: doc.id, text: data.text, sender: data.sender, createdAt: data.createdAt });
      });
      setMessages(msgs);
    });
    return () => unsub();
  }, [user, peerUid]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !peerUid || !newMessage.trim()) return;
    const ids = [user.uid, peerUid].sort();
    const convId = ids.join('_');
    await addDoc(collection(db, 'conversations', convId, 'messages'), {
      text: newMessage,
      sender: user.uid,
      createdAt: serverTimestamp(),
    });
    setNewMessage('');
  }

  if (!user || !peerUid) return null;
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Chat with {peerUid}</h1>
      <div style={{ border: '1px solid #ccc', padding: '1rem', height: '300px', overflowY: 'scroll' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ textAlign: m.sender === user.uid ? 'right' : 'left' }}>
            <span
              style={{
                display: 'inline-block',
                padding: '0.5rem',
                borderRadius: '8px',
                backgroundColor: m.sender === user.uid ? '#dcf8c6' : '#eee',
                marginBottom: '0.25rem',
              }}
            >
              {m.text}
            </span>
          </div>
        ))}
      </div>
      <form onSubmit={sendMessage} style={{ marginTop: '1rem', display: 'flex' }}>
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          style={{ flexGrow: 1 }}
          placeholder="Type a message…"
        />
        <button type="submit" style={{ marginLeft: '0.5rem' }}>
          Send
        </button>
      </form>
    </div>
  );
};

export default ChatPage;