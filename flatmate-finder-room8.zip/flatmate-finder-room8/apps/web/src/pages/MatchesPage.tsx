import React, { useEffect, useState } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { Profile as MatcherProfile, getTopKMatches } from '@matcher';
import { useNavigate } from 'react-router-dom';

interface MatchResult {
  peerUid: string;
  score: number;
  breakdown: { [key: string]: number };
}

/**
 * MatchesPage computes the top matches for the signed-in user. It fetches
 * all profiles from Firestore within the same city and applies the
 * matching algorithm locally. Each result can display a breakdown of
 * feature contributions when clicked. In a production version you would
 * call a Cloud Function instead and paginate results.
 */
const MatchesPage: React.FC = () => {
  const [user] = useAuthState(auth);
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const [explainIdx, setExplainIdx] = useState<number | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    async function computeMatches() {
      // Fetch current profile
      const profilesSnap = await getDocs(collection(db, 'profiles'));
      const candidates: MatcherProfile[] = [];
      let myProfile: MatcherProfile | null = null;
      profilesSnap.forEach((docSnap) => {
        const data = docSnap.data() as any;
        const profile: MatcherProfile = {
          uid: docSnap.id,
          city: data.city,
          budgetMin: data.budgetMin,
          budgetMax: data.budgetMax,
          moveInStart: new Date(data.moveInStart),
          moveInEnd: new Date(data.moveInEnd),
          cleanliness: data.cleanliness,
          noise: data.noise,
          social: data.social,
          visitors: data.visitors,
          smoking: data.smoking,
          bedtime: data.bedtime,
          wake: data.wake,
          zones: new Set<string>(Array.isArray(data.zones) ? data.zones : []),
          gender: data.gender,
          language: data.language,
          genderRequired: data.genderRequired,
          languageRequired: data.languageRequired,
          requiredPartnerGender: data.requiredPartnerGender,
          requiredPartnerLanguage: data.requiredPartnerLanguage,
        };
        if (docSnap.id === user.uid) myProfile = profile;
        else candidates.push(profile);
      });
      if (!myProfile) return;
      const results = getTopKMatches(myProfile, candidates, 20);
      const mapped = results.map(([profile, score, breakdown]) => ({
        peerUid: profile.uid,
        score,
        breakdown,
      }));
      setMatches(mapped);
    }
    computeMatches().catch(console.error);
  }, [user]);

  if (!user) return null;
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Your Top Matches</h1>
      {matches.length === 0 && <p>No matches found. Complete your quiz first.</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {matches.map((m, idx) => (
          <li key={m.peerUid} style={{ border: '1px solid #ccc', padding: '0.5rem', marginBottom: '0.5rem' }}>
            <strong>UID:</strong> {m.peerUid} — <strong>Score:</strong> {m.score.toFixed(2)}
            <button onClick={() => setExplainIdx(explainIdx === idx ? null : idx)} style={{ marginLeft: '1rem' }}>
              {explainIdx === idx ? 'Hide details' : 'Explain'}
            </button>
            <button onClick={() => navigate(`/chat/${m.peerUid}`)} style={{ marginLeft: '1rem' }}>
              Chat
            </button>
            {explainIdx === idx && (
              <div style={{ marginTop: '0.5rem' }}>
                <em>Feature contributions:</em>
                <ul>
                  {Object.entries(m.breakdown).map(([feature, value]) => (
                    <li key={feature}>
                      {feature}: {value.toFixed(2)}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MatchesPage;