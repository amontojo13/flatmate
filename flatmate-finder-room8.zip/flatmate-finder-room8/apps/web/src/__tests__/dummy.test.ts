import { describe, it, expect } from 'vitest';

describe('dummy test', () => {
  it('1 + 1 = 2', () => {
    expect(1 + 1).toBe(2);
  });
});