import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';

// Import Firebase config and initialize the app. This file reads configuration
// from environment variables injected by Vite (VITE_FIREBASE_*). See README.md
// for instructions on how to configure these variables locally.
import './firebase';

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
);