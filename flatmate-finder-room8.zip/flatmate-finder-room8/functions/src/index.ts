import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import { Profile, computeScore, getTopKMatches } from '@room8/matcher';

// Initialize the Firebase admin SDK once on cold start.
admin.initializeApp();

/**
 * HTTPS Callable function to recompute matches for a given user.
 *
 * This function expects the caller to be authenticated via Firebase Auth and
 * passes the user UID through the auth context. It fetches the caller's
 * profile and a limited set of candidate profiles from Firestore, computes
 * compatibility scores using the matcher library and writes the top K
 * matches back to a subcollection. The response contains the match list
 * for transparency in the client.
 */
export const match = functions.https.onCall(async (data, context) => {
  const uid = context.auth?.uid;
  if (!uid) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated.');
  }
  const k = typeof data?.k === 'number' && data.k > 0 ? data.k : 20;
  const db = admin.firestore();
  // Read the current user's profile
  const userDoc = await db.collection('profiles').doc(uid).get();
  if (!userDoc.exists) {
    throw new functions.https.HttpsError('not-found', 'Profile not found');
  }
  const userProfileData = userDoc.data() as any;
  const userProfile = firestoreToProfile(uid, userProfileData);
  // Fetch candidate profiles in the same city with overlapping budget.
  // In a real application this query should be indexed.
  const querySnapshot = await db
    .collection('profiles')
    .where('city', '==', userProfile.city)
    .get();
  const candidates: Profile[] = [];
  querySnapshot.forEach((doc) => {
    if (doc.id === uid) return;
    const data = doc.data();
    // Filter by budget overlap in JS to avoid complex Firestore queries
    if (data.budgetMax < userProfile.budgetMin || userProfile.budgetMax < data.budgetMin) {
      return;
    }
    candidates.push(firestoreToProfile(doc.id, data));
  });
  // Compute top K matches using pure TS library
  const results = getTopKMatches(userProfile, candidates, k);
  // Write results back to Firestore for caching and transparency
  const batch = db.batch();
  const matchesRef = db.collection('matches').doc(uid);
  const matchesList: any[] = [];
  results.forEach(([profile, score, breakdown]) => {
    matchesList.push({ peerUid: profile.uid, score, explain: breakdown, createdAt: admin.firestore.FieldValue.serverTimestamp() });
  });
  batch.set(matchesRef, { list: matchesList, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
  await batch.commit();
  return { matches: matchesList };
});

/** Convert Firestore document data into the Profile interface. */
function firestoreToProfile(uid: string, data: any): Profile {
  return {
    uid,
    city: data.city,
    budgetMin: data.budgetMin,
    budgetMax: data.budgetMax,
    moveInStart: data.moveInStart.toDate ? data.moveInStart.toDate() : new Date(data.moveInStart),
    moveInEnd: data.moveInEnd.toDate ? data.moveInEnd.toDate() : new Date(data.moveInEnd),
    cleanliness: data.cleanliness,
    noise: data.noise,
    social: data.social,
    visitors: data.visitors,
    smoking: data.smoking,
    bedtime: data.bedtime,
    wake: data.wake,
    zones: new Set<string>(Array.isArray(data.zones) ? data.zones : []),
    gender: data.gender,
    language: data.language,
    genderRequired: data.genderRequired,
    languageRequired: data.languageRequired,
    requiredPartnerGender: data.requiredPartnerGender,
    requiredPartnerLanguage: data.requiredPartnerLanguage,
  };
}