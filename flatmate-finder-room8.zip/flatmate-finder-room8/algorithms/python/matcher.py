"""
Roommate matching algorithm for Flatmate Finder (room8).

This module implements a simple yet effective matching algorithm between
student profiles. It applies a set of hard constraints (e.g. city and
budget overlap) before computing a weighted similarity score on
lifestyle and preference attributes. The result is a final score in
the range 0–100 and a per-feature breakdown used to explain matches.

Attributes
----------
    The matching process operates on ``Profile`` instances. See the
    documentation for :class:`Profile` for a description of the fields.

Design
------
    Hard constraints are applied first. If two profiles fail any
    mandatory constraint they are considered incompatible and receive a
    score of 0. Soft preferences are normalized to the range [0, 1]
    where 1 indicates perfect alignment. Weighted aggregation then
    yields the final score. See the project report for complexity
    analysis and edge case discussion.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Dict, Iterable, List, Optional, Set, Tuple


@dataclass
class Profile:
    """Represents a student's profile for matching.

    Parameters
    ----------
    uid:
        Unique identifier for the student (e.g. Firebase UID).
    city:
        City where the student intends to live. Only matches within the
        same city are considered.
    budget_min, budget_max:
        Minimum and maximum monthly rent the student can afford in EUR.
    move_in_start, move_in_end:
        Desired move‐in window as dates. A tolerance of ±45 days is
        allowed when comparing windows.
    cleanliness, noise, social, visitors:
        Likert ratings in the range [1, 5] describing the student's
        habits. Higher values mean more cleanliness, noise tolerance,
        sociability and number of visitors, respectively.
    smoking:
        ``True`` if the student smokes; ``False`` otherwise.
    bedtime, wake:
        Preferred bedtime and wake time as hour integers [0, 23]. The
        algorithm computes circular distances on a 24h clock.
    zones:
        Set of preferred neighbourhoods or districts in the city.
    gender, language:
        Self-reported gender and primary language. These may be used as
        hard constraints when the corresponding ``*_required`` flag is
        ``True``.
    gender_required, language_required:
        If ``True``, only profiles with the same gender or language
        respectively will match. If ``False``, mismatches contribute a
        score of 0.0 but do not block a match.
    required_partner_gender, required_partner_language:
        Optional fields specifying the desired partner gender or
        language. When provided, they override the student's own
        ``gender`` or ``language`` when evaluating hard constraints.
    """

    uid: str
    city: str
    budget_min: int
    budget_max: int
    move_in_start: date
    move_in_end: date
    cleanliness: int
    noise: int
    social: int
    visitors: int
    smoking: bool
    bedtime: int
    wake: int
    zones: Set[str]
    gender: str
    language: str
    gender_required: bool = False
    language_required: bool = False
    required_partner_gender: Optional[str] = None
    required_partner_language: Optional[str] = None

    def hard_constraints_ok(self, other: "Profile") -> bool:
        """Check if this profile can match with ``other`` based on hard constraints.

        The following conditions must hold:

        * Same city.
        * Budget intervals overlap by at least 1 EUR.
        * Move-in windows overlap within ±45 days.
        * Required gender/language matches if set.

        Returns
        -------
        bool
            ``True`` if all hard constraints pass; otherwise ``False``.
        """
        # City must match exactly
        if self.city.lower() != other.city.lower():
            return False

        # Budget overlap
        if self.budget_max < other.budget_min or other.budget_max < self.budget_min:
            return False

        # Move-in window overlap with ±45 days tolerance
        tolerance = timedelta(days=45)
        a_start = self.move_in_start - tolerance
        a_end = self.move_in_end + tolerance
        b_start = other.move_in_start - tolerance
        b_end = other.move_in_end + tolerance
        if a_end < b_start or b_end < a_start:
            return False

        # Gender requirement: if I require a partner gender, enforce it
        if self.gender_required:
            required_gender = self.required_partner_gender or self.gender
            if other.gender.lower() != required_gender.lower():
                return False
        # Similarly for the other side
        if other.gender_required:
            required_gender = other.required_partner_gender or other.gender
            if self.gender.lower() != required_gender.lower():
                return False

        # Language requirement
        if self.language_required:
            required_language = self.required_partner_language or self.language
            if other.language.lower() != required_language.lower():
                return False
        if other.language_required:
            required_language = other.required_partner_language or other.language
            if self.language.lower() != required_language.lower():
                return False

        return True


def _likert_similarity(a: int, b: int) -> float:
    """Compute similarity for Likert scale answers.

    Values are expected in [1, 5]. Similarity is 1 minus the
    normalized absolute difference.
    """
    diff = abs(a - b)
    return max(0.0, 1.0 - diff / 4.0)


def _binary_similarity(a: bool, b: bool) -> float:
    """Similarity for boolean attributes.

    Identical values score 1.0. If not identical, a small tolerance of
    0.3 is returned to account for willingness to tolerate smokers.
    """
    return 1.0 if a == b else 0.3


def _circular_similarity(a: int, b: int) -> float:
    """Similarity on a 24‑hour circular scale.

    Computes the shortest distance between two hours on a 24 hour clock
    and maps it to a similarity in [0, 1]. When the distance is 0 the
    similarity is 1; when the distance is 12 (opposite times) the
    similarity is 0.
    """
    distance = abs(a - b)
    if distance > 12:
        distance = 24 - distance
    return max(0.0, 1.0 - distance / 12.0)


def _interval_overlap_ratio(min1: int, max1: int, min2: int, max2: int) -> float:
    """Compute overlap/union ratio of two numerical intervals.

    Returns 0.0 if there is no overlap.
    """
    intersect = max(0, min(max1, max2) - max(min1, min2))
    union = max(max1, max2) - min(min1, min2)
    if union == 0:
        return 0.0
    return intersect / union if intersect > 0 else 0.0


def _jaccard_similarity(set1: Set[str], set2: Set[str]) -> float:
    """Compute the Jaccard similarity between two sets.

    Returns 1.0 when both sets are empty (interpreted as neutral) and
    0.0 when only one set is empty.
    """
    if not set1 and not set2:
        return 1.0
    if not set1 or not set2:
        return 0.0
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return intersection / union if union > 0 else 0.0


def compute_score(a: Profile, b: Profile) -> Tuple[float, Dict[str, float]]:
    """Compute the overall compatibility score between two profiles.

    This function applies hard constraints; if these fail a score of 0
    with an empty breakdown is returned. Otherwise it computes a
    weighted average of several similarity measures. The returned score
    ranges from 0 to 100.

    Parameters
    ----------
    a, b:
        The profiles to compare.

    Returns
    -------
    Tuple[float, Dict[str, float]]
        A tuple containing the final score and a dictionary mapping each
        feature to its contribution (0–100). The contributions sum to
        the total score.
    """
    if not a.hard_constraints_ok(b):
        return 0.0, {}

    # Compute similarity values for each attribute
    sims: Dict[str, float] = {}
    sims["cleanliness"] = _likert_similarity(a.cleanliness, b.cleanliness)
    sims["noise"] = _likert_similarity(a.noise, b.noise)
    sims["social"] = _likert_similarity(a.social, b.social)
    sims["visitors"] = _likert_similarity(a.visitors, b.visitors)
    sims["smoking"] = _binary_similarity(a.smoking, b.smoking)
    sims["bedtime"] = _circular_similarity(a.bedtime, b.bedtime)
    sims["wake"] = _circular_similarity(a.wake, b.wake)
    sims["budget"] = _interval_overlap_ratio(a.budget_min, a.budget_max,
                                              b.budget_min, b.budget_max)
    sims["location"] = _jaccard_similarity(a.zones, b.zones)

    # Weights must sum to 1.0
    weights: Dict[str, float] = {
        "cleanliness": 0.18,
        "noise": 0.14,
        "social": 0.14,
        "visitors": 0.10,
        "smoking": 0.12,
        "bedtime": 0.08,
        "wake": 0.06,
        "budget": 0.10,
        "location": 0.08,
    }

    # Weighted sum
    total = 0.0
    contributions: Dict[str, float] = {}
    for feature, weight in weights.items():
        contrib = sims[feature] * weight * 100.0
        contributions[feature] = contrib
        total += contrib

    return total, contributions


def get_top_k_matches(user: Profile, candidates: Iterable[Profile], k: int = 20) -> List[Tuple[Profile, float, Dict[str, float]]]:
    """Return the top ``k`` matches for a given user from a list of candidates.

    Parameters
    ----------
    user:
        The profile for which to find matches.
    candidates:
        A collection of other profiles to compare against. The user's
        own profile should not be included.
    k:
        Maximum number of matches to return.

    Returns
    -------
    List[Tuple[Profile, float, Dict[str, float]]]
        A list of tuples ``(candidate, score, breakdown)`` ordered by
        descending score. Only profiles passing hard constraints are
        returned.
    """
    scored: List[Tuple[Profile, float, Dict[str, float]]] = []
    for other in candidates:
        if other.uid == user.uid:
            continue
        score, breakdown = compute_score(user, other)
        if score > 0.0:
            scored.append((other, score, breakdown))
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:k]