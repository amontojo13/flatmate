from datetime import date

import unittest

from algorithms.python.matcher import Profile, compute_score, get_top_k_matches


def make_profile(**kwargs) -> Profile:
    """Helper to construct a profile with reasonable defaults.

    Only fields provided in ``kwargs`` will override the defaults. This
    function reduces boilerplate in tests.
    """
    defaults = dict(
        uid="x",
        city="Madrid",
        budget_min=400,
        budget_max=600,
        move_in_start=date(2025, 9, 1),
        move_in_end=date(2025, 9, 30),
        cleanliness=3,
        noise=3,
        social=3,
        visitors=3,
        smoking=False,
        bedtime=23,
        wake=7,
        zones={"Centro"},
        gender="female",
        language="es",
        gender_required=False,
        language_required=False,
    )
    defaults.update(kwargs)
    return Profile(**defaults)


class TestMatcher(unittest.TestCase):
    def test_hard_constraints_city_mismatch(self):
        a = make_profile(uid="a", city="Madrid")
        b = make_profile(uid="b", city="Barcelona")
        self.assertFalse(a.hard_constraints_ok(b))

    def test_hard_constraints_budget_overlap(self):
        a = make_profile(uid="a", budget_min=400, budget_max=600)
        b = make_profile(uid="b", budget_min=700, budget_max=800)
        self.assertFalse(a.hard_constraints_ok(b))
        # Overlap by 1 euro
        c = make_profile(uid="c", budget_min=600, budget_max=700)
        self.assertTrue(a.hard_constraints_ok(c))

    def test_hard_constraints_move_in_window(self):
        a = make_profile(move_in_start=date(2025, 9, 1), move_in_end=date(2025, 9, 30))
        # other start after tolerance
        b = make_profile(move_in_start=date(2026, 1, 1), move_in_end=date(2026, 1, 30))
        self.assertFalse(a.hard_constraints_ok(b))
        # within tolerance
        c = make_profile(move_in_start=date(2025, 11, 10), move_in_end=date(2025, 12, 1))
        self.assertTrue(a.hard_constraints_ok(c))

    def test_hard_constraints_gender_and_language(self):
        # require partner gender to be male
        a = make_profile(gender="female", gender_required=True, required_partner_gender="male")
        b = make_profile(uid="b", gender="female")
        self.assertFalse(a.hard_constraints_ok(b))
        male = make_profile(uid="c", gender="male")
        self.assertTrue(a.hard_constraints_ok(male))

    def test_similarity_features(self):
        a = make_profile(cleanliness=5, noise=1, social=5, visitors=1, smoking=True, bedtime=22, wake=8,
                         budget_min=400, budget_max=600, zones={"Centro", "Sol"})
        # identical
        b = make_profile(uid="b", cleanliness=5, noise=1, social=5, visitors=1, smoking=True, bedtime=22, wake=8,
                         budget_min=400, budget_max=600, zones={"Centro", "Sol"})
        score, details = compute_score(a, b)
        self.assertAlmostEqual(score, 100.0, places=3)
        # differences
        c = make_profile(uid="c", cleanliness=1, noise=5, social=1, visitors=5, smoking=False, bedtime=10, wake=20,
                         budget_min=500, budget_max=700, zones={"Chamartin"})
        score, details = compute_score(a, c)
        # All soft features differ; ensure score lower than perfect but non-zero due to budget overlap
        self.assertTrue(0.0 < score < 100.0)
        # make sure budget similarity computed correctly: overlap 0 for budgets yields score 0
        d = make_profile(uid="d", budget_min=1000, budget_max=1200)
        # Should fail hard constraints due to budget overlap
        score_d, details_d = compute_score(a, d)
        self.assertEqual(score_d, 0.0)
        self.assertEqual(details_d, {})

    def test_get_top_k_matches_ordering(self):
        user = make_profile(uid="user")
        candidates = [
            make_profile(uid="best", cleanliness=3, noise=3, social=3),
            make_profile(uid="high", cleanliness=5, noise=5, social=5),
            make_profile(uid="low", cleanliness=1, noise=1, social=1),
        ]
        matches = get_top_k_matches(user, candidates, k=2)
        # Should return top 2 highest scoring profiles
        self.assertEqual(len(matches), 2)
        # The candidate with identical preferences should rank first
        self.assertEqual(matches[0][0].uid, "best")
        self.assertEqual(matches[1][0].uid, "high")


if __name__ == "__main__":
    unittest.main()