"""
Matching algorithm reference implementation for Flatmate Finder.

This package provides a Python implementation of the roommate matching
algorithm used by the room8 MVP. It is separated into its own module so
that it can be unit tested independently from the web client or Firebase
functions. The course specification requires a reference implementation in
Python to illustrate algorithm design and complexity analysis.

Usage example::

    from algorithms.python.matcher import Profile, compute_score, get_top_k_matches
    alice = Profile(uid="alice", city="Madrid", budget_min=400, budget_max=600,
                    move_in_start=date(2025, 9, 1), move_in_end=date(2025, 10, 1),
                    cleanliness=4, noise=2, social=3, visitors=3,
                    smoking=False, bedtime=23, wake=7,
                    zones={"Centro", "Sol"},
                    gender="female", language="en", gender_required=False, language_required=False)
    # ... create bob profile
    score, details = compute_score(alice, bob)
    matches = get_top_k_matches(alice, [bob, charlie, dana], k=3)

See :func:`compute_score` and :func:`get_top_k_matches` for details.
"""

from .matcher import Profile, compute_score, get_top_k_matches

__all__ = ["Profile", "compute_score", "get_top_k_matches"]