# SECTION III: IMPLEMENTATION (MVP)

## Technology stack and rationale

Our goal was to build a minimum viable product that could be deployed quickly yet remained true to the core algorithms and data structures topics of the course. We chose a **Python** reference implementation for the matching logic because it allows us to reason about data structures, complexity and testing using the language taught in the course. The **web client** is implemented with **React and TypeScript** (via Vite) to provide a modern, type‑safe developer experience and because TypeScript closely mirrors the interface definitions used in the algorithm. The **matching algorithm** is also published as a pure TypeScript library so it can be reused on the client and in Firebase functions. For hosting and backend we rely on **Firebase** (Auth, Firestore, Cloud Functions and Hosting) because it removes boilerplate infrastructure work and provides built‑in authentication and realtime data storage. The complete monorepo layout is summarised below:

- `algorithms/python/` – the reference matcher with unit tests and a simple CLI.
- `packages/matcher-ts/` – a pure TypeScript implementation of the matcher library, compiled to CommonJS for reuse.
- `functions/` – Firebase Cloud Functions invoking the TS library to compute matches server‑side.
- `apps/web/` – a Vite React application with pages for login, profile, lifestyle quiz, matches and chat.
- `docs/` – diagrams and screenshots used in this report.

## System architecture

The high‑level architecture is shown in the diagram below. Students access the **React Web App** hosted on Firebase Hosting. It communicates with **Firebase Auth** for email/password authentication and with **Firestore** to store profiles, matches and chat messages. When a user requests matches, the web client either computes them locally using the **Matcher TS Library** or calls a **Cloud Function** which uses the same library to evaluate candidates and write the top‑K results into the `matches/{uid}` collection. A separate **Python Reference Algorithm** lives outside the production path and is used to verify correctness and measure performance during development.

![System architecture](architecture-diagram.png)

### Data model

Firestore collections and their purpose are summarised below:

| Collection | Document structure | Description |
|-----------|------------------|-------------|
| `users/{uid}` | `{email, createdAt}` | Account metadata stored by Firebase Auth (read‑only in client). |
| `profiles/{uid}` | `{city, budgetMin, budgetMax, moveInStart, moveInEnd, cleanliness, noise, social, visitors, smoking, bedtime, wake, zones[], gender, language, genderRequired, languageRequired}` | Lifestyle quiz answers and preferences. |
| `matches/{uid}` | `{list: [{peerUid, score, explain, createdAt}], updatedAt}` | Cache of the last matching run for a user. A Cloud Function writes this after computing scores. |
| `conversations/{convId}/messages/{msgId}` | `{sender, text, createdAt}` | Chat messages between two users. The conversation ID is deterministic: it is the two UIDs sorted and joined with an underscore. |

### API endpoints

The web app uses Firebase client libraries for most operations. Only one explicit backend endpoint is defined:

- **POST `/match`** – implemented as an HTTPS callable Firebase Cloud Function (see `functions/src/index.ts`). The function reads the caller's profile, filters candidate profiles in the same city with overlapping budgets, computes scores using the TypeScript matcher and writes the top‑K results to `matches/{uid}`. The response includes the computed list for transparency.

Authentication and Firestore read/write rules ensure that users can only read or write their own profiles and matches, and that messages can only be seen by conversation participants.

## Matching algorithm

### Intuition and idea

Students care about both **hard constraints** (e.g. they refuse to live outside a certain budget or city) and **soft preferences** (e.g. how clean they are, when they go to bed, or whether smoking is tolerated). The matching algorithm first checks hard constraints to quickly eliminate incompatible candidates. It then computes a weighted average of several similarity measures to derive a compatibility score between 0 and 100. Higher scores indicate greater compatibility. Weights were chosen based on interview insights (cleanliness, noise and sociability being the most important), and can be tuned later. The algorithm is symmetrical and deterministic: `score(a,b) = score(b,a)` and the same profile pair will always produce the same score.

### Pseudocode

```pseudo
function match_profiles(user, candidates, K):
    results ← []
    for each other in candidates:
        if other.uid = user.uid: continue
        if not hard_constraints_ok(user, other): continue
        score, breakdown ← soft_similarity(user, other)
        append (other, score, breakdown) to results
    sort results by score descending
    return first K elements of results

function hard_constraints_ok(a, b):
    return (a.city = b.city)
        and intervals_overlap(a.budget_min, a.budget_max, b.budget_min, b.budget_max)
        and windows_overlap(a.move_in_start, a.move_in_end, b.move_in_start, b.move_in_end, ±45 days)
        and (if a.gender_required then a.partner_gender = b.gender else true)
        and (if a.language_required then a.partner_language = b.language else true)

function soft_similarity(a, b):
    sims ← {}
    sims[cleanliness] ← 1 - |a.cleanliness - b.cleanliness| / 4
    sims[noise] ← 1 - |a.noise - b.noise| / 4
    sims[social] ← 1 - |a.social - b.social| / 4
    sims[visitors] ← 1 - |a.visitors - b.visitors| / 4
    sims[smoking] ← (a.smoking = b.smoking) ? 1 : 0.3
    sims[bedtime] ← 1 - min(|a.bedtime - b.bedtime|, 24 - |a.bedtime - b.bedtime|) / 12
    sims[wake] ← 1 - min(|a.wake - b.wake|, 24 - |a.wake - b.wake|) / 12
    sims[budget] ← interval_overlap_ratio(a.budget_min, a.budget_max, b.budget_min, b.budget_max)
    sims[location] ← jaccard_similarity(a.zones, b.zones)
    weights ← {cleanliness:0.18, noise:0.14, social:0.14, visitors:0.10,
               smoking:0.12, bedtime:0.08, wake:0.06, budget:0.10, location:0.08}
    total ← 0; breakdown ← {}
    for each feature in weights:
        contribution ← sims[feature] × weights[feature] × 100
        breakdown[feature] ← contribution
        total ← total + contribution
    return total, breakdown
```

### Python reference implementation

The full Python implementation can be found in `algorithms/python/matcher.py`. A simplified excerpt is shown below. It defines a `Profile` dataclass, performs hard‑constraint filtering and computes the weighted similarity:

```python
@dataclass
class Profile:
    uid: str
    city: str
    budget_min: int
    budget_max: int
    move_in_start: date
    move_in_end: date
    cleanliness: int
    noise: int
    social: int
    visitors: int
    smoking: bool
    bedtime: int
    wake: int
    zones: Set[str]
    gender: str
    language: str
    gender_required: bool = False
    language_required: bool = False
    required_partner_gender: Optional[str] = None
    required_partner_language: Optional[str] = None

def compute_score(a: Profile, b: Profile) -> Tuple[float, Dict[str, float]]:
    if not a.hard_constraints_ok(b):
        return 0.0, {}
    sims = {
        "cleanliness": 1 - abs(a.cleanliness - b.cleanliness) / 4,
        "noise": 1 - abs(a.noise - b.noise) / 4,
        ...
        "budget": interval_overlap_ratio(a.budget_min, a.budget_max,
                                          b.budget_min, b.budget_max),
        "location": jaccard_similarity(a.zones, b.zones),
    }
    weights = {...}
    total = 0; contributions = {}
    for f, w in weights.items():
        contributions[f] = sims[f] * w * 100
        total += contributions[f]
    return total, contributions
```

This implementation has been thoroughly tested with `unittest` to ensure that hard constraints are honoured and that similarities behave correctly at edge cases (no budget overlap, identical and opposite bedtimes, etc.).

### TypeScript library

The same algorithm is implemented in a reusable TypeScript package (`packages/matcher-ts/src/index.ts`). The functions `computeScore` and `getTopKMatches` mirror the Python version and can be imported by the web client or Cloud Functions. A lightweight Node test script under `packages/matcher-ts/test` verifies basic behaviour without requiring external testing frameworks.

### Complexity analysis

Let `n` be the number of candidate profiles in the same city. Hard‑constraint checks and similarity computations for each candidate run in **O(1)** time using primitive operations. Computing the score for a single candidate is thus **Θ(1)**. To find the top–`K` matches the algorithm must evaluate all `n` candidates and then sort the list of passing candidates. In the worst case all candidates pass, so sorting costs **O(n log n)**. However, `n` is bounded by the number of active users in one city (small in practice) and `K` is limited (e.g. 20). The overall complexity per matching run is **O(n log n)** time and **O(n)** additional space. When deployed as a scheduled function the cost remains manageable.

### Edge cases and tests

- **No overlap** – If budget intervals or move‑in windows do not overlap the pair is rejected immediately. Tests confirm that a single euro overlap is sufficient to permit matching.
- **Circular times** – Bedtime and wake times are treated on a 24‑hour circle. Opposite times (12 hours apart) yield zero similarity, while times near midnight wrap around correctly.
- **Tolerant smoking** – If one candidate smokes and the other does not, a small similarity of 0.3 is assigned. This captures toleration without blocking the match.
- **Empty zones** – When both zone sets are empty we interpret this as neutral (similarity = 1). If only one side is empty the similarity is 0.

The Python and Node test suites cover these edge cases. For example, unit tests verify that a candidate with identical preferences achieves a score of 100, that budget mismatches return a score of 0, and that ordering of matches reflects similarity rather than absolute values.

## Security and ethical considerations

Flatmate Finder handles sensitive personal data such as preferred budget, move‑in dates and lifestyle habits. We minimise data collection to what is strictly necessary for matching and never store passwords (authentication is delegated to Firebase Auth). Access to profiles and matches is protected by Firestore security rules: users may only read or write their own profile, and messages in a conversation are only readable by the two participants. All communication with the backend is encrypted via HTTPS. We deliberately avoid collecting or inferring sensitive attributes like race, religion or health status to respect privacy and comply with ethics guidelines. Data is stored in the EU region by default. Future work could include an external audit of the matching algorithm to ensure fairness across genders and nationalities.

## Screenshots of the MVP

Below are illustrative wireframes of the main screens of the MVP. They were generated programmatically to resemble the actual layout implemented in the React app.

### Login

![Login page](login.png)

### Lifestyle quiz

![Quiz page](quiz.png)

### Matches list with explain and chat buttons

![Matches page](matches.png)

### Chat

![Chat page](chat.png)

## Next steps

The current MVP demonstrates the end‑to‑end flow: a student registers with their university email, fills in a lifestyle quiz, obtains a ranked list of potential flatmates with transparent explanations, and initiates a chat. To advance towards a production‑ready product we plan to:

1. **Improve UI/UX** – Replace the wireframe styling with a responsive design, add input validation and accessibility features.
2. **Optimise queries** – Use Firestore composite indexes to filter candidates by city, budget and move‑in dates more efficiently.
3. **Fairness and feedback** – Investigate potential biases in the weighting scheme and allow users to provide feedback on matches to fine‑tune the algorithm.
4. **Mobile support** – Package the web app as a Progressive Web App (PWA) or native app using React Native.
5. **Deploy and monitoring** – Complete the Firebase Hosting deployment and set up monitoring for Cloud Functions and Firestore usage.

This section concludes the implementation of the room8 MVP. The repository accompanying this report contains the full source code, tests and documentation.