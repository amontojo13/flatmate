# Flatmate Finder (room8) MVP

Welcome to **Flatmate Finder** (codename **room8**), a lightweight matching platform that helps students find compatible flatmates.  This repository contains a complete academic **minimum viable product** (MVP) with a React front‑end, Firebase backend and a robust matching algorithm implemented in both Python and TypeScript.  The project grew out of an algorithms and data structures course; Section III of the accompanying report describes the implementation in detail (see `docs/section_iii.pdf`).

<p align="center">
  <img src="docs/architecture-diagram.png" alt="System architecture diagram" width="600"/>
</p>

## Features

This MVP implements the core flows required for a flatmate matching platform:

- **Student sign‑up and email verification** – sign up with your student email and verify your account through Firebase Auth.
- **Profile and lifestyle quiz** – fill out your personal profile (move‑in date, budget, preferred neighbourhoods) and a short lifestyle quiz (cleanliness, noise tolerance, social life, visitor policy, smoking and daily routines).  Answers are stored in Firestore.
- **Matching algorithm** – a two‑phase matcher applies hard constraints (city, budget overlap, move‑in date window and any required fields) then computes a weighted compatibility score out of 100.  A Python reference implementation lives under `algorithms/python` and a pure TypeScript version under `packages/matcher-ts`.  A Cloud Function (`functions/src/index.ts`) runs the matcher on demand and stores top‑K matches with per‑feature explanations.
- **Top‑K matches page** – view your best matches, including the overall score and a breakdown of each attribute’s contribution.  Transparent matching helps students understand why matches were suggested.
- **In‑app chat** – start a one‑to‑one conversation with a match.  Messages are streamed in real‑time via Firestore, and conversations are scoped to the two participants for privacy.
- **Tests and continuous integration** – unit tests cover edge cases of the matcher in both languages.  A GitHub Actions workflow runs type‑checking, linting and tests on every commit.
- **Documentation** – Section III of the project report (located in the root report PDF) details the design choices, pseudocode, complexity analysis and future work.  Screenshots and diagrams reside in `docs/`.

## Monorepo structure

```
flatmate-finder-room8/
├── apps/
│   └── web/           # Vite + React + TypeScript front‑end
├── algorithms/
│   └── python/        # Python reference matcher and tests
├── packages/
│   └── matcher-ts/    # Pure TypeScript matching library (shared by functions and web)
├── functions/         # Firebase Cloud Functions (TypeScript)
├── docs/              # Screenshots, diagrams and Section III PDF
├── .github/
│   └── workflows/ci.yml  # GitHub Actions CI configuration
├── tests/             # End‑to‑end / integration tests (placeholder)
├── package.json       # root workspace configuration (pnpm/yarn workspaces)
└── README.md          # you are here
```

## Getting started

### Prerequisites

- **Node.js ≥ 18** and **pnpm** (or yarn/npm).  Install pnpm via `npm install -g pnpm`.
- **Python 3.11** for running the reference matcher and Python tests.
- **Firebase CLI** if you wish to deploy (`npm install -g firebase-tools`).  Make sure you are logged in (`firebase login`) and have created a Firebase project.

### Setup

Clone the repository and install dependencies:

```bash
git clone https://github.com/<your‑org>/flatmate-finder-room8.git
cd flatmate-finder-room8
pnpm install
```

Create a `.env.local` file in `apps/web` with your Firebase configuration:

```properties
VITE_FIREBASE_API_KEY=your-api-key
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_APP_ID=your-app-id
```

Similarly, set up environment variables for Cloud Functions if needed (see `functions/src/index.ts`).

### Running the web app

To start the development server (React + Vite):

```bash
pnpm --filter=web run dev
```

The app exposes routes for `/login`, `/profile`, `/quiz`, `/matches` and `/chat/:conversationId`.  You can sign up with email, fill out the quiz and immediately see local matches (the client computes scores using the TS matcher library).  For server‑authoritative matching, deploy the Cloud Function and set the client to fetch `/match`.

### Running tests

#### TypeScript tests (Vitest)

```bash
pnpm --filter=matcher-ts run build      # compile TS to JS
pnpm --filter=matcher-ts run test       # run Node‑based tests for matcher-ts

pnpm --filter=web run test              # run React component tests (dummy placeholder)
```

#### Python tests (pytest)

```bash
cd algorithms/python
python -m pip install -r requirements.txt  # only standard library used here
python -m unittest discover -s tests
```

### Linting and formatting

The project uses ESLint and Prettier.  To run linting:

```bash
pnpm run lint
```

### Deploying to Firebase

1. Initialise Firebase in the root directory: `firebase init` and select **Functions**, **Firestore** and **Hosting**.  Use an existing project or create a new one.
2. Configure Firestore rules as described in Section III (restrict access to owners and conversation participants).
3. Deploy the functions and hosting:

   ```bash
   pnpm --filter=functions run build       # compile TS functions
   firebase deploy --only functions,hosting
   ```

After deployment you should be able to access the live site at `https://<your-project>.web.app` and call the matcher function at `https://<region>-<your-project>.cloudfunctions.net/match`.

### Data model & API

The app stores minimal user data in Firestore:

- `users/{uid}` – public account metadata (display name, email domain, createdAt).  Only the owner can write.
- `profiles/{uid}` – quiz answers and preferences (budget interval, move‑in date window, zones, lifestyle scores).  Used as input to the matcher.
- `matches/{uid}` – array of matches with `peerUid`, `score`, per‑feature explanation and timestamp.  Only the owner can read/write.
- `conversations/{conversationId}` – conversation metadata including participants.  Subcollection `messages/{messageId}` holds the message text, sender and timestamp.

The Cloud Function `POST /match` accepts the caller’s uid (derived from the Firebase Auth context), fetches eligible candidate profiles (same city & overlapping budget), applies the matching algorithm and writes the top‑K matches to `matches/{uid}`.  A nightly scheduled job can re‑rank all users.

## Architecture

The system follows the *lightweight web app* recommendation from the project brief: the React app handles user interaction, Firestore stores data and Cloud Functions encapsulate the matching logic.  The TypeScript matching library (`packages/matcher-ts`) is shared by both the client and server to ensure consistency, while the Python version (`algorithms/python/matcher.py`) serves as the reference implementation for correctness and complexity analysis.  A high‑level diagram is shown above and a more detailed explanation can be found in Section III of the report.

## Security and ethics

Our implementation respects students’ privacy by storing only non‑sensitive attributes required for matching.  Email verification ensures authenticity, and Firestore rules prevent unauthorised reads or writes.  The matching algorithm applies hard constraints (e.g. city, budget, move‑in dates) to avoid suggesting incompatible flatmates and provides a transparent explanation of the score.  Future work should include additional safeguards such as reporting inappropriate messages and optional identity verification.

## Contributing

Contributions are welcome!  Please fork this repository, create a feature branch and open a pull request.  Make sure to run tests and linting before submitting.  See the workflow in `.github/workflows/ci.yml` for the CI steps.

## Acknowledgements

This project was developed as part of an algorithms & data structures course at university.  The problem statement and grading rubric were provided by the instructors and are included in this repository.  Thanks to the teaching team for their guidance and evaluation.

## Next steps

- Add more robust quiz questions and allow students to weight attributes according to their preferences.
- Integrate a calendar to coordinate move‑in dates.
- Implement group chats and notifications.
- Perform user testing and iterate on the matching formula.

---

**Report PDF** – The updated project report, including the new Section III: *Implementation (MVP)*, is attached as a separate file in this repository.  You can also access the updated PDF via the file provided alongside this submission.